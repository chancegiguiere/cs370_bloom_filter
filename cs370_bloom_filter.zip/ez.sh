#!/bin/sh
python3 giguierc_bloom_filter.py -d dictionary.txt -i sample_input.txt -o3 output3.txt -o5 output5.txt
